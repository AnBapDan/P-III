package aula8;

public class Ex8_2 {

	public static void main(String[] args) {
		BMPViewer b = new BMPViewer();

	}

}
