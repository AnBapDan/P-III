package aula8;

public class Ex8_3 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		QQSM game = new QQSM();
		GameWindow window = new GameWindow(game);
	}

}
