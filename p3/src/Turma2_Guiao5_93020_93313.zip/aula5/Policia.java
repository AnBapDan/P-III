package aula5;

public interface Policia {
	public Const.Emergency getTipo();
}
