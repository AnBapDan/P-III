package aula5;

public class Const{
	public enum Color {
		Vermelho,
		Verde,
		Azul,
		Preto,
		Branco,
		Cinzento,
		Amarelo
	}
	
	public enum Emergency{
		INEM,
		Bombeiro,
		GNR,
		PSP,
		PJ
	}
}